﻿namespace WebApp_MultiTenant_v2.Utils
{
    public static class GraphScope
    {
        public const string UserReadAll = "User.Read.All";
    }
}
