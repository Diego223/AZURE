namespace WebApp_OpenIDConnect_DotNet.Services.GraphOperations
{
    public class WebOptions
    {
        public string GraphApiUrl { get; set; }
    }
}